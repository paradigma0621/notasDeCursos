package med.voll.api.infra.security;

public record DadosTokenJWT(String token) {
}
