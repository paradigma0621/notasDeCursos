package br.com.alura.escola.shared.dominio.evento;

public enum TipoDeEvento {
	
	ALUNO_MATRICULADO;

}
