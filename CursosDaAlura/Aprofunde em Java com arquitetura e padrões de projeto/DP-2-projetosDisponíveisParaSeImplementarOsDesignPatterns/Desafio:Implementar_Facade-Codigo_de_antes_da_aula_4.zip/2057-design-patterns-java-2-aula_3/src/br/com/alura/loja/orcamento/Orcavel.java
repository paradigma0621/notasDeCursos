package br.com.alura.loja.orcamento;

import java.math.BigDecimal;

public interface Orcavel {

	BigDecimal getValor();

}
